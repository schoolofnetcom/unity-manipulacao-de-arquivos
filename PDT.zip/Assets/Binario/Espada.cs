﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

[Serializable]
public class Espada{
    public string nome;
    public double poder;
    public double preco;
}
