﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

public class Binario : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        if (Input.GetKeyDown(KeyCode.S))
        {
            Espada excalibur = new Espada();
            excalibur.nome = "Excalibur";
            excalibur.preco = 10;
            excalibur.poder = 100;
            SalvarEspada(excalibur);
        }

        if (Input.GetKeyDown(KeyCode.L))
        {
            ListarEspadas();
        }
	}

    void SalvarEspada(Espada espada)
    {
        BinaryFormatter bf = new BinaryFormatter();
        FileStream stream = new FileStream(Application.dataPath + "/espadas.dat", FileMode.Append);
        bf.Serialize(stream, espada);
        stream.Close();
    }

    void ListarEspadas()
    {
        BinaryFormatter bf = new BinaryFormatter();
        FileStream stream = new FileStream(Application.dataPath + "/espadas.dat", FileMode.Open);
        // A primeira espada
        Espada primeiraEspada = bf.Deserialize(stream) as Espada;
        // A segunda vez
        Espada segundaEspada = bf.Deserialize(stream) as Espada;
        stream.Close();
        Debug.Log(primeiraEspada.nome);
        Debug.Log(primeiraEspada.poder);

        Debug.Log(segundaEspada.nome);
        Debug.Log(segundaEspada.poder);
    }
}
