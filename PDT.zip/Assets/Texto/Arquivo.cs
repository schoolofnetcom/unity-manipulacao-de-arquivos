﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;

public class Arquivo : MonoBehaviour {

    string arquivo = "Assets/texto/espadas.txt";

	// Use this for initialization
	void Start () {
        
    }
	
	// Update is called once per frame
	void Update () {
        if (Input.GetKeyDown(KeyCode.S))
        {
            RegistrarEspada("Espada de ouro", 10.0f, 240f, arquivo);
            RegistrarEspada("Espada de bronze", 8.0f, 120f, arquivo);
        }
	}

    void RegistrarEspada(string nome,float peso, float preco, string arquivo)
    {
        StreamWriter escritor = new StreamWriter(arquivo, true);
        escritor.Write(nome);
        escritor.Write(',');
        escritor.Write(peso);
        escritor.Write(',');
        escritor.WriteLine(preco);
        escritor.Close();
    }
}
