﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Pontuador : MonoBehaviour {


    int pontos = 0;

    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        if (Input.GetKeyDown(KeyCode.A))
        {
            pontos++;
            Debug.Log("Pontuacao atual: " + pontos);
        }

        if (Input.GetKeyDown(KeyCode.S))
        {
            Debug.Log("Salvando informação de pontos...");
            // Salvando
            PlayerPrefs.SetInt("pontuacaorecente",pontos);
        }

        if (Input.GetKeyDown(KeyCode.C))
        {
            Debug.Log("Carregando informações...");
            int informacao = PlayerPrefs.GetInt("pontuacaorecente");
            Debug.Log("Pontuação salva: " + informacao);
        }

        if (Input.GetKeyDown(KeyCode.D))
        {
            PlayerPrefs.DeleteAll();
        }

        Debug.Log(PlayerPrefs.HasKey("pontuacaorecente"));
	}
}
